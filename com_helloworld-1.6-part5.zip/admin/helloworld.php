Hello World administration
